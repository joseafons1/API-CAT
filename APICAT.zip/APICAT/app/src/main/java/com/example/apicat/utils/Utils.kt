package com.example.apicat.utils

object Utils {
    const val Base = "https://catfact.ninja/"
}