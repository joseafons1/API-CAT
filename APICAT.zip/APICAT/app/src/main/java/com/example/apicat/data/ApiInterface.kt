package com.example.apicat.data

import com.example.apicat.modelos.CatFacts
import retrofit2.Response
import retrofit2.http.GET

interface ApiInterface {

    @GET("fact")
    suspend fun getRandomFact(): Response<CatFacts>
}