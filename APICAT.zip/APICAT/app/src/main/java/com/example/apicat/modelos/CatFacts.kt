package com.example.apicat.modelos

data class CatFacts(
    val fact: String = "",
    val length: Int = 0
)